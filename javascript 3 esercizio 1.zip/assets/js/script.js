var btn = document.getElementById('inserisci');
var utenti = [];
var errore = document.getElementById('errore');
function calcoloEta(age) {
    var annoUtente = document.getElementById('data').value;
    var data = new Date(annoUtente);
    var annoAttuale = new Date();
    var month_diff = Date.now() - data.getTime();
    var age_dt = new Date(month_diff);
    var year = age_dt.getUTCFullYear();
    var age = Math.abs(year - 1970);
    return age;
}


function Utenti(_nome, _cognome) {
    this.nome = _nome;
    this.cognome = _cognome;
}
window.addEventListener('DOMContentLoaded', init());

function init() { //popolamento array
    errore.style.visibility = 'hidden';
    if (utenti.length > 0) {
        stampaCatalogo();
    }
}

btn.addEventListener('click', (e) => {
    e.preventDefault;
    let newNome = document.getElementById('nome').value;
    let newCognome = document.getElementById('cognome').value;

    let newUtenti = new Utenti(newNome, newCognome);
    if (newNome == '' || newCognome == '') {//dichiariamo il messaggio d'errore se i campi richiesti sono vuoti
        errore.style.visibility = 'visible';
        return;
    };

    utenti.push(newUtenti);
    stampaUtenti();
})
function stampaUtenti() {
    let lista = document.getElementById('lista');
    errore.style.visibility = 'hidden';
    let stringa = '';
    lista.innerHTML = '';
    utenti.forEach((elemento) => {
        stringa += `<tr><td>${elemento.nome} ${elemento.cognome}</td><td>${calcoloEta()}</td></tr>`;
    });
    lista.innerHTML = stringa;
}